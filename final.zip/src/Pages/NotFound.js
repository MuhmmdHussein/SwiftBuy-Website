import React from "react";


function NotFound (){
    return(

         <h1 className="text-center m-auto text-red-950"> Page NotFound</h1>
        
    )
}

export default NotFound;